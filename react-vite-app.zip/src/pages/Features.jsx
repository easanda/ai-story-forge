import React from "react";

function Features() {
  return <h1>Features Page</h1>;
}

export default Features;
